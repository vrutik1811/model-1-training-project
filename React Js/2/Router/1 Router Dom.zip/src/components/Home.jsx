import Nav from './Nav'
import Footer from './Footer'

const Home = ()=>{
    return (
        <div>
            <Nav />
            <h1>Hi home</h1>
            <Footer />
        </div>
    )
}

export default Home