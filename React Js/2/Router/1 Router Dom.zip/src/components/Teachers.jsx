import Nav from './Nav'
import Footer from './Footer'

const Teachers = ()=>{
    return (
        <div>
            <Nav />
            <h1>Hello Teachers</h1>
            <Footer />
        </div>
    )
}

export default Teachers