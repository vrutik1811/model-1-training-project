import Nav from './Nav'
import Footer from './Footer'

const Holidays = ()=>{
    return (
        <div>
            <Nav />
            <h1>Welcome holidays</h1>
            <Footer />
        </div>
    )
}

export default Holidays